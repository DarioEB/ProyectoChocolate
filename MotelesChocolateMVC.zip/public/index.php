<?php 

require_once __DIR__ . '/../includes/app.php';

use Controller\AdminController;
use MVC\Router;
use Controller\PageController;
use Controller\LoginController;

$router = new Router();

$router->get('/', [PageController::class, 'index']);
$router->get('/sucursalCorrientes', [PageController::class, 'sucursalCorrientes']);
$router->get('/sucursalChaco', [PageController::class, 'sucursalChaco']);
$router->get('/login', [PageController::class, 'login']);

$router->get('/login', [LoginController::class, 'sigin']);
$router->post('/login', [LoginController::class, 'sigin']);
$router->get('/logout', [LoginController::class, 'sigout']);

$router->get('/admin', [AdminController::class, 'index']);
$router->get('/admin/habitaciones', [AdminController::class, 'habitaciones']);
$router->post('/admin/habitaciones', [AdminController::class, 'habitaciones']);

$router->get('/admin/crearHabitaciones', [AdminController::class, 'crear']);
$router->post('/admin/crearHabitaciones', [AdminController::class, 'crear']);
$router->get('/admin/eliminarHabitaciones', [AdminController::class, 'eliminar']);
$router->get('/admin/editarHabitacion', [AdminController::class, 'editar']);
$router->post('/admin/editarHabitacion', [AdminController::class, 'editar']);

$router->get('/admin/infoHabitaciones', [AdminController::class, 'info']);

$router->post('/admin/infoHabitaciones', [AdminController::class, 'eliminarImagen']);
$router->rutear();