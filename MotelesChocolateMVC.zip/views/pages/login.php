
<section class="login-img">
    <!-- <picture>
        <source srcset="../build/img/im-login.webp" type="image/webp">
        <source srcset="../build/img/im-login.JPG" type="image/jpg">
        <img loading="lazy" src="../build/img/im-login.JPG" alt="">
    </picture> -->
    <div class="background">
        <div class="container content-login">
            <div class="logo-login">
                <a href="/">
                    <img src="../build/img/logo.png" alt="Logotipo">
                </a>
            </div>

            <div class="form-login">
                <div class="form-links">
                    <a href="#" id="ini" class="link">Iniciar Sesión</a>
                    <a href="#" id="reg" class="no-link">Registrarse</a>
                </div>

                <form class="ini form-l" method="POST">
                    <div class="box-in">
                        <label for="nombre">Nombre de Usuario</label>
                        <input type="text" id="nombre" name="ini[nombre]" placeholder="Tu Nombre de Usuario">


                        <label for="password">Contraseña</label>
                        <input type="password" id="password" name="ini[password]" placeholder="Tu Contraseña">
                        
                    </div>

                    <div class="box-rem">
                        <a href="#">¿Olvidaste tu Contraseña?</a>
                        <div class="rem">
                            <label for="rem">Recordar</label>
                            <input type="checkbox">
                        </div>
                    </div>

                    <div class="box-submit">
                        <input type="hidden" name="tipo" value="inicio">
                        <input type="submit" class="button" value="Iniciar Sesión">
                    </div>
                </form>

                <form class="reg form-l" method="POST">
                    <div class="box-in">
                        <label for="nombre">Nombre de Usuario</label>
                        <input 
                            type="text" 
                            id="nombre" 
                            name="reg[nombre]" 
                            value="<?php echo $usuario->nombre; ?>"
                            placeholder="Tu Nombre de Usuario">
                        <?php if ( isset($errores['nombre']) ) { ?> 
                            <p class="alert-error-reg"><?php echo $errores['nombre']; ?></p>
                        <?php } ?>

                        <label for="email">Correo Electrónico</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="reg[email]" 
                            value="<?php echo $usuario->email; ?>"
                            placeholder="Tu Correo Electronico">
                        <?php if ( isset($errores['email'])) { ?> 
                            <p class="alert-error-reg"><?php echo $errores['email']; ?></p>
                        <?php } ?>

                        <label for="telefono">Teléfono</label>
                        <input 
                            type="tel" 
                            id="telefono" 
                            name="reg[telefono]" 
                            value="<?php echo $usuario->telefono; ?>"
                            placeholder="Tu Número de Teléfono">
                        <?php if ( isset($errores['telefono']) ) { ?> 
                            <p class="alert-error-reg"><?php echo $errores['telefono']; ?></p>
                        <?php } ?>

                        <label for="password">Contraseña</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="reg[password]" 
                            value="<?php echo $usuario->password; ?>"
                            placeholder="Tu contraseña">
                        <?php if ( isset($errores['password']) ) { ?> 
                            <p class="alert-error-reg"><?php echo $errores['password']; ?></p>
                        <?php } ?>

                        <?php if ( isset($errores['tipo']) ) { ?> 
                            <p class="alert-error-reg"><?php echo $errores['tipo']; ?></p>
                        <?php } ?>
                        <input type="hidden" name="reg[tipo]" value="no-admin">
                    </div>
                    <div class="box-inf">
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est exercitationem voluptatem dolorem sed deserunt, harum id omnis pariatur.</p>
                    </div>

                    <div class="box-submit">
                        <input type="hidden" name="tipo" value="registro">
                        <input type="submit" class="button" value="Registrarme">
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>