<section class="container">
    <div class="content-slider">
        <div class="slider">
            <picture>
                <source srcset="../build/img/im-recomendacion1.webp" type="image/webp">
                <source srcset="../build/img/im-recomendacion1.jpg" type="image/jpeg">
                <img loading="lazy" src="../build/img/im-recomendacion1.jpg" alt="Imagen Slider">
            </picture>
            <picture>
                <source srcset="../build/img/im-recomendacion2.webp" type="image/webp">
                <source srcset="../build/img/im-recomendacion2.jpg" type="image/jpeg">
                <img loading="lazy" src="../build/img/im-recomendacion2.jpg" alt="Imagen Slider">
            </picture>
            <picture>
                <source srcset="../build/img/im-recomendacion3.webp" type="image/webp">
                <source srcset="../build/img/im-recomendacion3.jpg" type="image/jpeg">
                <img loading="lazy" src="../build/img/im-recomendacion3.jpg" alt="Imagen Slider">
            </picture>
            <picture>
                <source srcset="../build/img/im-recomendacion4.webp" type="image/webp">
                <source srcset="../build/img/im-recomendacion4.jpg" type="image/jpeg">
                <img loading="lazy" src="../build/img/im-recomendacion4.jpg" alt="Imagen Slider">
            </picture>
            <picture>
                <source srcset="../build/img/im-recomendacion5.webp" type="image/webp">
                <source srcset="../build/img/im-recomendacion5.jpg" type="image/jpeg">
                <img loading="lazy" src="../build/img/im-recomendacion5.jpg" alt="Imagen Slider">
            </picture>
        </div>
    </div>
</section>

<section class="container">
    <div class="content-text-info">
        <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Omnis perferendis tenetur, unde aspernatur eos quidem accusamus minus quam eius quo doloremque quaerat sit amet non magnam atque possimus dolor officiis?
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Rem atque dignissimos, tempora eos nemo doloribus nulla cum, facilis quam dolorem sunt impedit nesciunt assumenda mollitia tenetur ratione consequuntur error eum!
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos libero tempore beatae ullam provident explicabo, iusto sunt ab soluta minima ducimus, doloremque consequuntur dignissimos, nemo maxime sint quibusdam rem quo.
        </p>
    </div>
</section>

<section class="news ">
    <div class="container">
        <div class="content-newsletter">
            <h1>Suscribite a Nuestro Newsletter</h1>
            <div class="newsletter">
                <div class="newsletter-text">
                    <p>Recibí todas las semanas promociones en servicios y productos Chocolate</p>
                </div>
                <form class="newsletter-form">
                    <label for="email">Correo Eléctronico</label>
                    <div class="news-inputs">
                        <input type="email" name="email" id="email" placeholder="Tu Correo Electrónico">
                        <input type="submit" class="fas fa-sign-in-alt" value="&#xf2f6">
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>