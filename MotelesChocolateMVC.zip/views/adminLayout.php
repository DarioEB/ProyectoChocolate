<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="../build/css/all.min.css">
    <link rel="stylesheet" href="../build/css/app.css">
</head>

<body class="body-admin">
    <header class="container content-admin">
        <div class="mobile-admin">
            <i class="fas fa-bars"></i>
        </div>
        <div class="logo-admin">
            <a href="/admin">
                <img src="../build/img/logo.png" alt="">
            </a>
        </div>
        <div class="log-out">
            <a href="/logout" title="Cerrar Sesión"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </header>


    <?php echo $content; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script type="text/javascript" src="../build/js/bundle.js"></script>
</body>

</html>