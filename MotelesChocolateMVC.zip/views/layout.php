<?php
    if(!isset($_SESSION)){
        session_start();
    } 
    if( isset($_SESSION['admin']) ) {
        header('Location: /admin');
    }
    $user = $_SESSION['login'] ?? false;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moteles Chocolate</title>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
    <link rel="stylesheet" href="../build/css/all.min.css">
    <link rel="stylesheet" href="../build/css/app.css">
</head>
<body>
    <header class="header">
        <div class="container content-header">
            <div class="header-info">
                <div class="info"><i class="fas fa-check"></i><p>Sin reserva Previa</p></div>
                <div class="info"><i class="fas fa-phone"></i><p>Corrientes: 3784593737</p></div>
                <div class="info"><i class="fas fa-phone"></i><p>Chaco: 3784592626</p></div>
                <div class="info"><i class="far fa-clock"></i><p>Abierto: 24 horas</p></div>
                
                <div class="redes">
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-spotify"></i></a>
                </div>
            </div>
            <div class="header-nav">
                <div class="logo">
                    <a href="/"><img src="../build/img/logo.png" alt="Logotipo"></a>
                    <div class="mobile">
                        <i class="fas fa-bars"></i>
                    </div>
                </div>
                <nav class="nav">
                    <ul>
                        <li >
                            <div class="box box-hab" id="habitaciones">
                                <a >Habitaciones</a>
                                <div class="menu-hab">
                                    <ul>
                                        <li><a href="/sucursalCorrientes">Sucursal Corrientes</a></li>
                                        <li><a href="/sucursalChaco">Sucursal Chaco</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li >
                            <div class="box box-shop"  id="sex-shop">
                                <a href="">Sex Shop</a>
                                <div class="menu-shop">
                                    <ul>
                                        <li><a href="">Dildos</a></li>
                                        <li><a href="">Contillon</a></li>
                                        <li><a href="">Vibradores</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="box"><a href="">Servicios</a></li>
                        <li class="box"><a href="">Promociones</a></li>
                        <li class="box"><a href="">Eventos</a></li>
                        <li class="box"><a href="">Nosotros</a></li>
                        <li class="box">
                            <?php if( $user ): ?>
                                <a href="/logout"><i class="fas fa-sign-out-alt"></i></a>
                            <?php else: ?>
                                <a href="/login"><i class="far fa-user"></i></a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>  


    <?php echo $content; ?>

    <footer class="footer">
        <div class="container content-footer">
            <div class="pay-method">
                <div class="img-method">
                    <p>Metodos de pagos aceptados: </p>
                    <img src="../build/img/metodosdepago.webp" alt="">
                </div>
                <div class="redes">
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-spotify"></i></a>
                </div>
            </div>
            <div class="termi-cond">
                <a href="#">Terminos y Condiciones</a>
                <a href="#">Politicas de Privacidad</a>
                <a href="#">Nosotros</a>
            </div>
        </div>
    </footer>

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script>
    <script type="text/javascript" src="../build/js/bundle.js"></script>
</body>
</html>

