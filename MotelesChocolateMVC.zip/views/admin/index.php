<!-- <div class=""> -->
<section class="menu container">
    <h1>Administración</h1>
    <div class="content-menu">
        <ul>
            <li class="item">
                <a href="/admin/habitaciones">
                    <picture>
                        <source srcset="../build/img/img_cart1.webp" type="image/webp">
                        <source srcset="../build/img/img_cart1.jpg" type="image/jpeg">
                        <img loading="lazy" src="../build/img/img_cart1.jpg" alt="Imagen cart1">
                    </picture>
                </a>
                <div class="text-item">
                    <h2>Habitaciones</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam eligendi alias sunt quasi sint, beatae, veritatis incidunt reprehenderit, officia earum ipsa a? Illo maiores praesentium, magnam quaerat repellat velit itaque.</p>
                </div>
            </li>
            <li class="item">
                <a href="/admin/sexshop">
                    <picture>
                        <source srcset="../build/img/img_cart2.webp" type="image/webp">
                        <source srcset="../build/img/img_cart2.jpg" type="image/jpeg">
                        <img loading="lazy" src="../build/img/img_cart2.jpg" alt="Imagen cart1">
                    </picture>
                </a>
                <div class="text-item">
                    <h2>Sex Shop</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam eligendi alias sunt quasi sint, beatae, veritatis incidunt reprehenderit, officia earum ipsa a? Illo maiores praesentium, magnam quaerat repellat velit itaque.</p>
                </div>
            </li>
            <li class="item">
                <a href="/admin/sucursales">
                    <picture>
                        <source srcset="../build/img/img_cart3.webp" type="image/webp">
                        <source srcset="../build/img/img_cart3.jpg" type="image/jpeg">
                        <img loading="lazy" src="../build/img/img_cart3.jpg" alt="Imagen cart1">
                    </picture>
                </a>
                <div class="text-item">
                    <h2>Surcursales</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam eligendi alias sunt quasi sint, beatae, veritatis incidunt reprehenderit, officia earum ipsa a? Illo maiores praesentium, magnam quaerat repellat velit itaque.</p>
                </div>
            </li>
        </ul>
    </div>
</section>
<!-- </div> -->