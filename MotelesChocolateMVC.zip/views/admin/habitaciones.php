<section class="menu container">
    <h1>Habitaciones</h1>

    <div class="button-create">
        <a href="/admin/crearHabitaciones" class="button">Agregar Nueva Habitación</a>
    </div>

    <!-- State Imagen -->
    <?php if( !is_null($imgState) ): ?>
            <div class="img-state">
            <?php if( intval($imgState) === 1): ?>
                <h3>Imagen Almacenada Correctamente</h3>
            <?php elseif( intval($imgState) === 0): ?>
                <h3>Imagen no seleccionada o no valida</h3>
            <?php endif; ?>
                <div class="img-state-close">
                    <i class="fas fa-times"></i>
                </div>
            </div>
    <?php endif; ?>

    <table class="tabla">
        <thead>
            <tr>
                <th>Id</th>
                <th>Nombre</th>
                <th><i class="fas fa-dollar-sign"></i></th>
                <th><i class="fas fa-heart"></i></th>
                <th>Sucursal</th>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($habitaciones as $habitacion ): ?>
            <tr>
                <td><?php echo $habitacion->id; ?></td>
                <td><?php echo $habitacion->nombre; ?></td>
                <td>$ <?php echo $habitacion->precio; ?> </td>
                <td><?php echo $habitacion->likes; ?></td>
                <td><?php echo $habitacion->sucursal; ?></td>
                <td>
                    <a href="/admin/infoHabitaciones?id=<?php echo $habitacion->id; ?>" id="<?php echo $habitacion->id; ?>" title="Ver más información"><i class="fas fa-plus"></i></a>
                    <a href="/admin/habitaciones" id="<?php echo $habitacion->id; ?>" class="add-img" title="Agregar Imagen"><i class="fas fa-images"></i></a>
                    <a href="/admin/eliminarHabitacion?id=<?php echo $habitacion->id; ?>" title="Eliminar Habitación"><i class="fas fa-trash-alt"></i></a>
                    <a href="/admin/editarHabitacion?id=<?php echo $habitacion->id; ?>" title="Actualizar Datos"><i class="fas fa-cogs"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="set-images">
        <form method="POST" enctype="multipart/form-data">
            <label for="imagen">Imagen</label>
            <input type="file" name="imagen" accept="image/jpeg, image/png">
            <input type="hidden" id="id-hab" name="id-hab" value="">
            <div class="box-submit">
                <input type="submit" class="button" value="Agregar">
            </div>
        </form>
        <div class="close">
            <i class="fas fa-times"></i>
        </div>
    </div>
    

</section>