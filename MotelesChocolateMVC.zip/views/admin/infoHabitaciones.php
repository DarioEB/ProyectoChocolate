<section class="container ">
    <div class="box-prev">
        <a href="/admin/habitaciones" class="button-prev">Volver</a>
    </div>

    <?php if (is_null($imagenes) && is_null($habitacion)) : ?>
        <div class="section-error-hab">
            <p><?php echo $mensaje; ?></p>
        </div>
    <?php else: ?>

        <div class="content-info">
            <div class="section-info-hab">
                <ul>
                    <li>
                        <p>Id: <?php echo $habitacion->id; ?></p>
                    </li>
                    <li>
                        <p>Nombre: <?php echo $habitacion->nombre; ?></p>
                    </li>
                    <li>
                        <p>Precio: $<?php echo $habitacion->precio; ?></p>
                    </li>
                    <li>
                        <p>Likes: <?php echo $habitacion->likes; ?></p>
                    </li>
                    <li>
                        <p>Sucursal: <?php echo $habitacion->sucursal; ?></p>
                    </li>
                    <li>
                        <p>Registro: <?php echo $habitacion->registro; ?></p>
                    <li>
                </ul>
            </div>

            <div class="section-imgs-hab">
                <ul>
                    <?php foreach ($imagenes as $imagen) : ?>
                        <li>
                            <img src="../imagenes/<?php echo $imagen->nombre; ?>" title="Imagen Habitacion <?php echo $habitacion->nombre; ?>" alt="Imagen Habitacion<?php echo $habitacion->nombre; ?>">
                            <form class="img-option" method="POST" >
                                <input name="id-habitacion" value="<?php echo $habitacion->id; ?>" type="hidden">
                                <input name="id-imagen" value="<?php echo $imagen->id; ?>" type="hidden" title="Eliminar Imagen">
                                <input type="submit" class="fas fa-trash-alt" value="&#xf2ed">
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

    <?php endif; ?>
</section>