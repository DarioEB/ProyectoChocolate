<label for="nombre">Nombre</label>
<input type="text" id="nombre" name="hab[nombre]" value="<?php echo s($habitacion->nombre); ?>" placeholder="Nombre de la Habitación">
<?php if( isset($errores['nombre'])): ?>
    <p class="alert-error-reg"><?php echo $errores['nombre']; ?></p>
<?php endif; ?>

<label for="precio">Precio por Noche</label>
<input type="number" slot="any" id="precio" name="hab[precio]" value="<?php echo s($habitacion->precio); ?>" placeholder="Precio por Noche">
<?php if( isset($errores['precio'])): ?>
    <p class="alert-error-reg"><?php echo $errores['precio']; ?></p>
<?php endif; ?>

<label for="sucursal">Sucursal</label>
<select name="hab[sucursal]">
    <option value="0" selected disabled>-- Seleccione la sucursal --</option>
    <?php foreach ($sucursales as $sucursal) : ?>
        <?php if ($sucursal->nombre == $habitacion->sucursal) : ?>
            <option value="<?php echo s($sucursal->id); ?>" selected><?php echo $sucursal->nombre; ?></option>
        <?php else : ?>
            <option value="<?php echo s($sucursal->id); ?>"><?php echo $sucursal->nombre; ?></option>
        <?php endif; ?>
    <?php endforeach; ?>
</select>
<?php if( isset($errores['sucursal'])): ?>
    <p class="alert-error-reg"><?php echo $errores['sucursal']; ?></p>
<?php endif; ?>