<section class="container">
    <div class="box-prev">
        <a href="/admin/habitaciones" class="button-prev">Volver</a>
    </div>
    
    <div class="content-create-hab">
    <h1>Registro de Habitación</h1>
        <form method="POST">
            <?php include_once __DIR__ . '/formularioHabitaciones.php'; ?>
            <div class="box-submit">
                <input type="submit" class="button" value="Registrar">
            </div>
        </form>
    </div>
</section>