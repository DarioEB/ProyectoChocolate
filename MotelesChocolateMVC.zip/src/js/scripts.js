document.addEventListener('DOMContentLoaded', function () {
    console.log('Hola');
    if( window.location.href.indexOf('/login') > -1) {
        var ini = document.querySelector('#ini');
        var reg = document.querySelector('#reg');

        var formIni = document.querySelector('.ini');
        var formReg = document.querySelector('.reg');
        const alert = document.querySelectorAll('.alert-error-reg');
        console.log(alert);
        if( alert.length > 0 ) {
            console.log('Detecta el alert');
            reg.classList.remove('no-link');
            reg.classList.add('link');
            ini.classList.remove('link');
            ini.classList.add('no-link');
            formReg.style.opacity = '1';
            formIni.style.display = 'none';
            formReg.style.diplay = 'flex';
        } else {
            console.log('No detecta el alert');
            formReg.style.display = 'none';
        }
    }

    if(window.location.href.indexOf('admin/habitaciones') > -1) {
        var imagenID = '';
        var addImg = document.querySelectorAll('.add-img');
        var formImg = document.querySelector('.set-images');
        var close = document.querySelector('.close .fas');
        var inputHidden = document.querySelector('#id-hab');

        // console.log(formImg);
        addImg.forEach( (currentValue, index, addImg) => {
            // console.log(currentValue.getAttribute('id'));
            currentValue.addEventListener('click', (event) => {
                event.preventDefault();
                // console.log(currentValue.getAttribute('id'));
                imagenID = currentValue.getAttribute('id');
                formImg.style.opacity = 1;
                formImg.style.display = 'block';
                inputHidden.setAttribute('value', imagenID);
            });
        });

        close.addEventListener('click', () =>  {
            formImg.style.opacity = 0;
            formImg.style.display = 'none';
            inputHidden.setAttribute('value', 0);
        });


        var imgStateClose = document.querySelector('.img-state-close i');
        if( imgStateClose != null) {
            console.log(window.location.pathname);
            console.log('existe');
            imgStateClose.addEventListener('click', () => {
                document.querySelector('.img-state').style.display = 'none';
                window.location.href = window.location.pathname;
            });
        } else {
            console.log('no existe');
        }
         
    }
});


$(document).ready(function () {

    // tooltips();

    if (window.location.href === 'http://localhost:3000/') {
        console.log('ENTRADA 1')
        const mobile = $('.mobile .fas');
        const nav = $('.nav > ul');
        const body = $('body');
        var cont = 1;
        mobile.click(function () {
            if (cont == 1) {
                nav.animate({
                    left = '0'
                }, 300);
                body.css({ overflow: 'hidden' });
                cont = 0;
            } else {
                nav.animate({
                    left: '-100%'
                }, 300)
                body.css({
                    'overflow-y': 'scroll'
                });
                cont = 1;
            }
        });

        if( window.innerWidth < 945) {
            console.log('hOLA 9829');
            $('#habitaciones').click(function() {
                console.log('HABITACION');
                $('.menu-hab ul').slideToggle('slow');
            });
        }

        $('.slider').bxSlider({
            mode: 'fade',
            captions: true,
            responsive: true,
            pager: true
        });

        const lsp = $('.bx-wrapper .bx-controls-direction .bx-prev');
        const lsn = $('.bx-wrapper .bx-controls-direction .bx-next');
        lsp.empty();
        lsn.empty();

        lsp.append('&#10094;');
        lsn.append('&#10095;');
    }


    if (window.location.href.indexOf('/login') > -1) {
        
        var ini = $('#ini');
        var reg = $('#reg');

        var formIni = $('.ini');
        var formReg = $('.reg');


        console.log(window.location.href);

        ini.click(function (event) {
            event.preventDefault();
        })

        reg.click(function (event) {
            event.preventDefault();
            reg.removeClass('no-link');
            ini.removeClass('link');
            ini.addClass('no-link');
            reg.addClass('link');
            formIni.animate({
                opacity = 0
            });
            formIni.css({ display: 'none' });

            formReg.css({ display: 'flex' });
            formReg.animate({
                opacity = 1
            });

        })
        ini.click(function(event) {
            event.preventDefault();
            ini.removeClass('no-link');
            reg.removeClass('link')
            reg.addClass('no-link');
            ini.addClass('link');
            formReg.animate({
                opacity: 0
            })
            formReg.css({display: 'none'});
            formIni.css({display: 'flex'});
            formIni.animate({
                opacity: 1
            })
        })
    }

    
});