<?php

function conectarDB() {
    $db = new mysqli('localhost', 'c2080510_motelch', '0H3Wrb7gc5', 'c2080510_motelch');
    if(!$db) {
        echo "Error al intentar conectar la Base de datos";
        exit;
    } 
    return $db;
}
