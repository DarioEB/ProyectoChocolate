<?php

define('CARPETA_IMAGENES', $_SERVER['DOCUMENT_ROOT'] . '/imagenes/');

function debug($var) {
    echo "<pre>";
    var_dump($var);
    echo "</pre>";
    exit ;
} 

function isAdmin() {
    if($_SESSION['login']) {
        return true;
    } else {
        return false;
    }
}

function isUser() {
    if($_SESSION['login']){
        return true;
    } else {
        return false;
    }
}

function validarTipo($tipo) {
    $tipos = ['inicio', 'registro'];
    return in_array($tipo, $tipos);
}

function s($html) : string {
    $s = htmlspecialchars($html);
    return $s;
}

function validarORedireccionar(string $url) {
    // VALIDAR L url por ID valido
    $id = $_GET['id'];
    $id = filter_var($id, FILTER_VALIDATE_INT);

    if(!$id) {
        header("Location: ${url}");
    }

    return $id;
}