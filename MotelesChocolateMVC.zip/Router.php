<?php

namespace MVC;

class Router {

    public $routesGET = [];
    public $routesPOST = [];

    public function get($url, $fn) {
        $this->routesGET[$url] = $fn;
    }

    public function post($url, $fn) {
        $this->routesPOST[$url] = $fn;
    }

    public function rutear() {
        $urlAct = $_SERVER['PATH_INFO'] ?? '/';
        $method = $_SERVER['REQUEST_METHOD'];
        
        if( $method === 'GET') {
            $fn = $this->routesGET[$urlAct] ?? null;
        } else if( $method === 'POST') {
            $fn = $this->routesPOST[$urlAct] ?? null;
        }

        if($fn) {
            call_user_func($fn, $this);
        } else {
            echo "Pagina no encontrada";
        }
    }

    public function render($view, $data = []) {
        foreach($data as $key => $value) {
            $$key = $value;
        }
        ob_start();
        include_once __DIR__ . "/views/$view.php";
        $content = ob_get_clean();
        if( $view == 'pages/login' ){
            include_once __DIR__ . "/views/loginLayout.php";
        } else if ( strpos($view, 'admin') !== false) {
            // debug('Incluye el archivo');
            include_once __DIR__ . "/views/adminLayout.php";
        } else {
            include_once __DIR__ . "/views/layout.php";
        }
        
    }
}