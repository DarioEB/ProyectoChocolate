<?php

namespace Controller;

use MVC\Router;
use Model\Imagen;
use Model\Sucursal;
use Model\Habitacion;
use Intervention\Image\ImageManagerStatic as Image;

class AdminController
{

    public static function index(Router $router)
    {

        $router->render('admin/index');
    }

    public static function habitaciones(Router $router)
    {
        $habitaciones = Habitacion::allRooms();
        $imgState = $_GET['imgState'] ?? null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombreImagen = md5(uniqid(rand(), true)) . ".jpg";
            if ($_FILES['imagen']['tmp_name']) {
                // debug($_FILES);
                $args = [
                    'nombre' => $nombreImagen,
                    'habitacion' => $_POST['id-hab']
                ];
                $img = Image::make($_FILES['imagen']['tmp_name'])->fit(800, 600);
                $obImagen = new Imagen($args);

                if (!is_dir(CARPETA_IMAGENES)) {
                    mkdir(CARPETA_IMAGENES);
                }
                $img->save(CARPETA_IMAGENES . $nombreImagen);
                $result = $obImagen->guardar();
                if ($result) {
                    header('Location: /admin/habitaciones?imgState=1');
                }
            } else {
                header('Location: /admin/habitaciones?imgState=0');
            }
        }

        $router->render('admin/habitaciones', [
            'habitaciones' => $habitaciones,
            'imgState' => $imgState
        ]);
    }

    public static function crear(Router $router)
    {
        $errores = Habitacion::getErrores();
        $sucursales = Sucursal::all();
        $habitacion = new Habitacion();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $habitacion = new Habitacion($_POST['hab']);
            $errores = $habitacion->validar();
            if (empty($errores)) {
                $result = $habitacion->guardar();
                if ($result) {
                    header('Location: /admin/habitaciones');
                }
            }
        }
        $router->render('admin/crearHabitaciones', [
            'sucursales' => $sucursales,
            'habitacion' => $habitacion,
            'errores' => $errores
        ]);
    }

    public static function info(Router $router)
    {
        $id = validarORedireccionar('/admin/habitaciones');
        $habitacion = Habitacion::sRooms($id);
        $mensaje = '';
        if (!is_null($habitacion)) {
            $imagenes = Imagen::searchImgs($id);
        } else {
            $imagenes = null;
            $mensaje = "Habitación no Encontrada";
        }
        $router->render('admin/infoHabitaciones', [
            'habitacion' => $habitacion,
            'imagenes' => $imagenes,
            'mensaje' => $mensaje
        ]);
    }

    public static function editar(Router $router)
    {
        $idHabitacion = validarORedireccionar('/admin/habitaciones');
        $habitacion = Habitacion::sRooms($idHabitacion);
        $sucursales = Sucursal::all();
        $mensaje = null;
        if ($habitacion == null) {
            $mensaje = 'Habitación no encontrada';
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $args = $_POST['hab'];
            $habitacion->sincronizar($args);
            $habitacion->actualizar();
        }
        $router->render('admin/editarHabitacion', [
            'mensaje' => $mensaje,
            'habitacion' => $habitacion,
            'sucursales' => $sucursales
        ]);
    }

    public static function eliminarImagen(Router $router)
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $idImagen = $_POST['id-imagen'];
            $idHabitacion = $_POST['id-habitacion'];
            if ($idImagen != null) {
                $imagen = Imagen::search($idImagen);
                $file = CARPETA_IMAGENES . $imagen->nombre;
                if (is_file($file)) {
                    $result = $imagen->eliminar();
                    if ($result) {
                        unlink($file);
                        $header = 'Location: /admin/infoHabitaciones?id=' . $idHabitacion;
                        header($header);
                    }
                }
            }
        }
    }
}
