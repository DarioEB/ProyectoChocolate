<?php

namespace Controller;

use MVC\Router;

class PageController {

    public static function index(Router $router) {

        $router->render('pages/index');
    
    }

    public static function habitaciones(Router $router) {

        $router->render('pages/habitaciones');
    }

    public static function login(Router $router) {

        $router->render('pages/login');
    }
}