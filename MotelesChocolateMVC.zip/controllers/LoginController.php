<?php

namespace Controller;

use MVC\Router;
use Model\Usuario;

class LoginController
{

    public static function sigin(Router $router)
    {
        $errores = Usuario::getErrores();
        $usuarioReg = new Usuario;
        // debug($errores);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tipo = $_POST['tipo'];
            if (validarTipo($tipo)) {
                if ($tipo === 'registro') {
                    $usuarioReg = new Usuario($_POST['reg']);
                    $errores = $usuarioReg->validar();
                    // debug($errores);
                    if(empty($errores)) {
                        $usuarioReg->crear();
                    }
                } else if ($tipo === 'inicio') {
                    $usuario = new Usuario($_POST['ini']);

                    $auth = $usuario->existeUsuario();
                    if (!is_null($auth)) { // Comprobación del email
                        $pass = $usuario->comprobarPassword($auth->password);
                        if ($pass) { // Comprobarción del password
                            session_start();

                            if ($auth->tipo === 'admin') {
                                $_SESSION['admin'] = true;
                                header('Location: /admin');
                            } else if ($auth->tipo === 'no-admin') {
                                $_SESSION['login'] = true;
                                header('Location: /');
                            }
                        }
                    }
                }
            }
        }
        $router->render('pages/login', [
            'errores' => $errores,
            'usuario' => $usuarioReg
        ]);
    }

    public static function sigout(Router $router) {
        session_start();

        $_SESSION = [];
        header('Location: /');
    }
}
