const {src, dest, watch, parallel} = require('gulp');

const sass = require('gulp-sass');
const concat = require('gulp-concat');
const terser = require('gulp-terser-js');
const cache = require('gulp-cache');
const imagemin = require('gulp-imagemin');
const notify = require('gulp-notify');
const webp = require('gulp-webp');

const paths = {
    scss: 'src/scss/**/*.scss',
    js: 'src/js/**/*.js',
    img: 'src/img/**/*'
}

function css() {
    return src( paths.scss)
    .pipe(sass())
    .pipe(dest('./public/build/css/'))
}

function javascript() {
    return src( paths.js )
        .pipe(concat('bundle.js'))
        .pipe(terser())
        .pipe(dest('./public/build/js'))
}

function imagenes() {
    return src( paths.img )
        .pipe(cache(imagemin({optimizationlevel: 3})))
        .pipe(dest('./public/build/img'))
        .pipe(notify({message: 'Imagen Optimizada'}))
}

function versionWebp() {
    return src( paths.img )
        .pipe( webp() )
        .pipe( dest('./public/build/img') )
        .pipe( notify({message: 'Imagen Complatada'}))
}

function watchArchivos() {
    watch(paths.scss, css);
    watch(paths.js, javascript);
    watch(paths.img, imagenes);
    watch(paths.img, versionWebp);
}

exports.default = parallel(css, javascript, imagenes, versionWebp, watchArchivos);