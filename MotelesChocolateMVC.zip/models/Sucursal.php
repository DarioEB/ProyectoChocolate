<?php

namespace Model;

class Sucursal extends ActiveRecord{

    public static $tabla = 'sucursales';

    public function __construct($args = []) {
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? '';
        $this->localidad = $args['localidad'] ?? '';
        $this->registro = date('Y-m-d H:i:s');
    }
    
}