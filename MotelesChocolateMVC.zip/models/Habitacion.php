<?php

namespace Model;

class Habitacion extends ActiveRecord{

    protected static $tabla = 'habitaciones';
    protected static $columnasDB = ['id', 'nombre', 'precio', 'likes', 'sucursal', 'registro'];

    public function __construct($args = []){
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? null;
        $this->precio = $args['precio'] ?? null;
        $this->likes = $args['likes'] ?? '0';
        $this->sucursal = $args['sucursal'] ?? null;
        $this->registro = date('Y-m-d H:i:s');
    }

    public static function sRooms($id) {    // Metodo estatico propio de Habitacion
        $id_sano = self::$db->escape_string($id);
        $query = " SELECT H.id, H.nombre, H.precio, H.likes, S.nombre sucursal, H.registro";
        $query .= " FROM " . self::$tabla . " H";
        $query .= " LEFT JOIN sucursales S"; 
        $query .= " ON S.id = H.sucursal WHERE H.id = " . $id_sano;
        $query .= " LIMIT 1 ";
        // debug($query);
        $result = self::$db->query($query);
        if ( $result->num_rows ) {
            $registro = $result->fetch_assoc();
            $objeto = self::crearObjeto($registro);
        } else {
            $objeto = null;
        }
        return $objeto;
    }


    public static function allRooms() {
        $query = "SELECT H.id, H.nombre, H.precio, H.likes, S.nombre sucursal,  H.registro "; 
        $query .= "FROM " . self::$tabla . " H LEFT JOIN sucursales S ON S.id = H.sucursal ORDER BY H.id";

        $objetos = self::consultarSQL($query);
        return $objetos;
    }

    public function validar() {
        if(!$this->nombre) {
            $errores['nombre'] = 'El nombre es Obligatorio';
        }
        if(!$this->precio) {
            $errores['precio'] = 'El precio es Obligatorio';
        }
        if(!$this->sucursal) {
            $errores['sucursal'] = 'La sucursal es Obligatoria';    
        }
        return $errores;
    }
}