<?php 

namespace Model;

class Usuario extends ActiveRecord{

    protected static $columnasDB = ['id', 'nombre', 'email', 'telefono', 'password', 'tipo', 'registro'];
    protected static $tabla = 'usuarios';

    public function __construct($args = []) {
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? null;
        $this->email = $args['email'] ?? null;
        $this->telefono = $args['telefono'] ?? null;
        $this->password = $args['password'] ?? null;
        $this->tipo = $args['tipo'] ?? null;
        $this->registro = date('Y-m-d H:i:s');
    }

    

    public function validar(){

        if(!$this->nombre) {
            self::$errores['nombre'] = 'El nombre es obligatorio';
        }
        if(!$this->email) {
            self::$errores['email'] = 'El email es obligatorio';
        }
        if(!$this->telefono) {
            self::$errores['telefono'] = 'El telefono es obligatorio';
        } else {
            if(strlen($this->telefono) != 10 ){
                self::$errores['telefono'] = 'El teléfono debe contener 10 digitos';   
            }
        }
        if(!$this->password) {
            self::$errores['password'] = 'El password es obligatorio';
        }
        if($this->tipo != 'no-admin') {
            self::$errores['tipo'] = 'El valor de Tipo ingresado es incorrecto';
        }
        return self::$errores;
    }

    
    

    public function crear() {
        $datos = $this->sanitizarDatos();
        $datos['password'] = $this->hashPassword($datos['password']);

        $query = "INSERT INTO " . self::$tabla . " ( ";
        $query .= join(', ', array_keys($datos));
        $query .= " ) VALUES ( '";
        $query .= join("', '", array_values($datos));
        $query .= "') ;";
        
        $result = self::$db->query($query);
        if( $result ) {
        
            header('Location: /login?resultado=1');
        }
    }

    public function hashPassword($password) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        return $passwordHash;
    }


    public function existeUsuario() {
        $datos = $this->sanitizarDatos();
        $query = "SELECT * FROM " . self::$tabla . " WHERE nombre = " . "'${datos['nombre']}'";

        $result = self::$db->query($query);
        
        if( $result->num_rows ) {
            $registro = $result->fetch_assoc();
            $objeto = self::crearObjeto($registro);
        } else {
            $objeto = null;
        }
        return $objeto;
    }

    public function comprobarPassword($passwordHash) {
        $pass = password_verify($this->password, $passwordHash);
        return $pass;
    }
    

}
