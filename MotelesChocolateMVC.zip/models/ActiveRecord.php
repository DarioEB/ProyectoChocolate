<?php

namespace Model;

class ActiveRecord {

    protected static $tabla = '';
    protected static $db = '';
    protected static $columnasDB = [];
    protected static $errores = [];

    public static function setDB($database) {
        self::$db = $database;
    }

    public static function getErrores() {
        return self::$errores;
    }

    public function datos() {
        $datos = [];
        foreach(static::$columnasDB as $col) {
            if($col === 'id') continue;
            $datos[$col] = $this->$col;
        }
        return $datos;
    }

    public function sanitizarDatos() {
        $datos = $this->datos();
        $sano = [];
        foreach($datos as $key => $value) {
            $sano[$key] = self::$db->escape_string($value);
        }
        return $sano;
    }

    public static function all() {
        $query = " SELECT * FROM " . static::$tabla . "; ";
        $objetos = self::consultarSQL($query);
        return $objetos;
    }

    public function guardar() {
        $datos = $this->sanitizarDatos();
        // debug($datos);
        $query = "INSERT INTO " . static::$tabla . " (";
        $query .= join(", ", array_keys($datos));
        $query .= ") VALUES ('";
        $query .= join("', '", array_values($datos));
        $query .= "') ";
        $result = self::$db->query($query);
        return $result;
    }

    public static function search($id){
        $id_sano = self::$db->escape_string($id);
        $query = "SELECT * FROM " . static::$tabla . " WHERE id = " . $id_sano;
        $result = self::$db->query($query);
        if( $result->num_rows) {
            $registro = $result->fetch_assoc();
            $objeto = self::crearObjeto($registro);
        } else {
            $objeto = null;
        }
        return $objeto;
    }

    public function eliminar() {
        $id_sano = self::$db->escape_string($this->id);
        $query = "DELETE FROM " . static::$tabla . " WHERE id = " . $id_sano;
        $result = self::$db->query($query);
        return $result;
    }

    public static function consultarSQL($query) {
        $objetos = [];
        $result = self::$db->query($query);
        // debug($result);
        while($registro = $result->fetch_assoc()) {
            $objetos[] = self::crearObjeto($registro);
        }
        return $objetos;
    }

    public static function crearObjeto($registro) {
        $objeto = new static;

        foreach($registro as $key => $value) {
            if(property_exists($objeto, $key)) {
                $objeto->$key = $value;
            }
        }
        return $objeto;
    }

    public function actualizar() {
        $datos = $this->sanitizarDatos();
        $valores = [];
        foreach($datos as $key => $value) {
            $valores[] = "{$key} = '{$value}'";
        }
        $query = " UPDATE " . static::$tabla . " SET ";
        $query .= join(', ', $valores);
        $query .= " WHERE id = '" . self::$db->escape_string($this->id) . "' ";
        $query .= " LIMIT 1 ";
        $result = self::$db->query($query);
        if($result) {
            header('Location: /admin/habitaciones');
        }
    }

    public function sincronizar($args = []) {
        foreach($args as $key => $value) {
            if(property_exists( $this, $key ) && !is_null($value)) {
                $this->$key = $value;
            }
        }
    }
}