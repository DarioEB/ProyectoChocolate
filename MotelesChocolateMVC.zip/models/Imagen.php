<?php

namespace Model;

class Imagen extends ActiveRecord{

    protected static $tabla = 'imagenes';
    protected static $columnasDB = ['id', 'nombre', 'habitacion'];

    public function __construct( $args = [] ){
        $this->id = $args['id'] ?? null;
        $this->nombre = $args['nombre'] ?? null;
        $this->habitacion = $args['habitacion'] ?? null;
    }


    public function datos() {
        $datos = [];
        foreach(self::$columnasDB as $col) {
            if($col == 'id') continue;
            $datos[$col] = $this->$col;
        }
        return $datos;
    }

    

    public static function searchImgs($id) {
        $id_sano = self::$db->escape_string($id);
        $query = "SELECT * FROM " . self::$tabla . " WHERE habitacion = " . $id_sano;
        
        $imagenes = self::consultarSQL($query);
        return $imagenes;
    }

   

}